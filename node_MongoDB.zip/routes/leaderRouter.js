const express = require("express");
const body_parser = require("body-parser");

const Leaders = require('../models/leaders');

const leaderRouter = express.Router();

leaderRouter.use(body_parser.json());

leaderRouter
  .route("/")
  .get(async (req, res, next) => {
    try {
      const leader = await Leaders.find({});
      res.setHeader('Content-type', 'application/json').status(200).json(leader);
    } catch (error) {
      next(error)
    }
  })
  .post(async (req, res, next) => {
    const body = req.body
    try {
      const created = await Leaders.create(body)
      res.setHeader('Content-type', 'application/json').status(200).json(created);

    } catch (error) {
      next(error)
    }
  })
  .put((req, res, next) => {
    res.statusCode = 403;
    res.end("PUT operation not supported on /leaders");
  })
  .delete(async (req, res, next) => {
    try {
      const deleted = await Leaders.remove({});
      res.setHeader('Content-type', 'application/json').status(200).json(deleted);
    } catch (error) {
      next(error)
    }
  });

leaderRouter
  .route("/:leaderId")
  .get(async (req, res, next) => {
    const id = req.params.leaderId
    try {
      const leader = await Leaders.findById(id);
      res.setHeader('Content-type', 'application/json').status(200).json(leader);
    } catch (error) {
      next(error)
    }
  })
  .post((req, res, next) => {
    res.statusCode = 403;
    res.end(
      `POST operation not supported on /leaders/${req.params.leaderId}`
    );
  })
  .put(async (req, res, next) => {
    const id = req.params.leaderId
    const updates = req.body
    try {
      const updated = await Leaders.findByIdAndUpdate(id, { $set: updates }, { new: true })
      res.setHeader('Content-type', 'application/json').status(200).json(updated);
    } catch (error) {
      next(error)
    }
  })
  .delete(async (req, res, next) => {
    const id = req.params.leaderId
    try {
      const deleted = await Leaders.findByIdAndRemove(id);
      res.setHeader('Content-type', 'application/json').status(200).json(deleted);

    } catch (error) {
      next(error)
    }
  });

module.exports = leaderRouter;
