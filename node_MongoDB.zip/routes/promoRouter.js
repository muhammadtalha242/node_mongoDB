const express = require("express");
const body_parser = require("body-parser");
const mongoose = require('mongoose');

const Promotion = require('../models/promotions');

const promoRouter = express.Router();

promoRouter.use(body_parser.json());

promoRouter
  .route("/")
  .get(async (req, res, next) => {
    try {
      const promotions = await Promotion.find({});
      res.setHeader('Content-type', "application/json").status(200).json(promotions);
    } catch (error) {
      next(error);
    }

  })
  .post(async (req, res, next) => {
    const body = req.body
    try {
      const created = await Promotion.create(body);
      res.setHeader('Content-type', "application/json").status(200).json(created);
    } catch (error) {
      next(error);
    }
  })
  .put((req, res, next) => {
    res.statusCode = 403;
    res.end("PUT operation not supported on /promos");
  })
  .delete(async (req, res, next) => {
    try {
      const deleted = await Promotion.remove({});
      res.setHeader('Content-type', "application/json").status(200).json(deleted);
    } catch (error) {
      next(error);
    }
  });

promoRouter
  .route("/:promoId")
  .get(async (req, res, next) => {
    const id = req.params.promoId
    try {
      const promo = await Promotion.findById(id);
      res.setHeader('Content-type', "application/json").status(200).json(promo);

    } catch (error) {
      next(error)
    }
  })
  .post((req, res, next) => {
    res.statusCode = 403;
    res.end(
      `POST operation not supported on /promotions/${req.params.promoId}`
    );
  })
  
  .put(async (req, res, next) => {
    const id = req.params.promoId;
    const updates = req.body;
    try {
      const promo = await Promotion.findByIdAndUpdate(id, {
        $set: updates
      }, { new: true })
      res.setHeader('Content-type', "application/json").status(200).json(promo);

    } catch (error) {
      next(error)
    }
  })
  .delete(async (req, res, next) => {
    const id = req.params.promoId
    try {
      const deleted = await Promotion.findByIdAndRemove(id);
      res.setHeader('Content-type', 'application/json').status(200).json(deleted);
    } catch (error) {
      next(error)
    }
  });

module.exports = promoRouter;
